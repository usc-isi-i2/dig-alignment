## Ontologies for DIG


### schema.org
We use the [schema.org](https://schema.org/docs/schemas.html) vocabulary. The OWL file in schema.org is broken, so we use the OWL file in http://topbraid.org/schema/ where they provide a conversion of the vocabulary to usable OWL.
